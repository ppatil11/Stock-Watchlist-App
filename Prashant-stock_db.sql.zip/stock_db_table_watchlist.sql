
-- --------------------------------------------------------

--
-- Table structure for table `watchlist`
--

CREATE TABLE `watchlist` (
  `symbol` varchar(18) NOT NULL,
  `name` varchar(128) NOT NULL,
  `last` double DEFAULT NULL,
  `change` double DEFAULT NULL,
  `pctchange` double DEFAULT NULL,
  `volume` int(11) DEFAULT NULL,
  `tradetime` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `watchlist`
--

INSERT INTO `watchlist` (`symbol`, `name`, `last`, `change`, `pctchange`, `volume`, `tradetime`) VALUES
('AMD ', ' Adv Micro Devices', 12.09, -0.19, -1.55, 125643297, '2017-06-12 18:04:00');
